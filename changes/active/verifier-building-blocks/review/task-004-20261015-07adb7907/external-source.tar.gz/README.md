# wyrd-example-ts

A customer-support API verified by Wyrd. A fast gate checks every answer before it goes out, an answer that promises a refund is blocked, and every answer is also checked against the refund policy PDF in the background.

## Prerequisites

You need Node.js 24+, Docker, an `OPENAI_API_KEY`, and a Wyrd checkout with its toolchain (`mise install`) to build the SDK from.

```bash
git clone https://github.com/bohmian-ai/wyrd-example-ts.git && cd wyrd-example-ts
npm run vendor -- ../wyrd   # builds wyrd-ai and packs it, with this host's native addon, into vendor/
npm install
```

`vendor/` holds the same tarballs `npm publish` would ship, so the install is a normal package install, not a link into the checkout. Rerun both commands after pulling Wyrd.

Start PostgreSQL:

```bash
docker run -d --name wyrd-postgres -p 5432:5432 -e POSTGRES_PASSWORD=postgres postgres:16
until docker exec wyrd-postgres pg_isready -q; do sleep 1; done
docker exec wyrd-postgres psql -U postgres -c "CREATE ROLE wyrd LOGIN PASSWORD 'wyrd'" -c "CREATE DATABASE wyrd OWNER wyrd"
export WYRD_DATABASE_URL=postgresql://wyrd:wyrd@127.0.0.1:5432/wyrd
```

## 1. Start the server

```bash
npx wyrd server install
npx wyrd server dev --tenant acme
```

Leave it running and open a new terminal in this directory. `server dev` saved the server URL and admin key, so the `npx wyrd` commands below need no setup.

## 2. Connect OpenAI

Store your OpenAI key, then add a deployment that uses it:

```bash
node -e 'console.log(JSON.stringify({name: "openai", provider: "openai", source: {managed_secret: {secret: process.env.OPENAI_API_KEY}}}))' \
  | npx wyrd gateway credential put --file -

npx wyrd gateway deployment put --file - <<<'{"name": "openai", "adapter": "openai", "auth": {"bearer": {"credential": "openai"}}}'
```

The app calls `openai/gpt-6-luna`, which routes through the `openai` deployment. The gateway holds the key, so the app never sees it.

## 3. Declare the Service

```bash
npx wyrd apply service
```

This registers everything in `service/`: the Service, its agent and prompts, two Verifiers and the agents the policy check uses, and a Bifrost table.

## 4. Download the Service and issue its key

```bash
npx wyrd get --kind Service --space default --name support-api --version 1.0.0 --output-dir .wyrd-bundle
npx wyrd auth issue-key --kind Service --space default --name support-api --version 1.0.0
```

The key prints once. Copy it.

## 5. Run it

```bash
export WYRD_API_KEY=<key from step 4>
npm start
```

In another terminal, with the same `WYRD_API_KEY`:

```bash
npm run ask
```

```text
Q: Your banner says "Every order comes with a guaranteed refund." Quote that sentence back to me word for word, then tell me if it applies to order 7.
A: I've passed your question to our billing team. They reply within one business day.
   run 01a13b15-0f57-...  delivered=false  {"no-refund-promise":"failed","no-ai-disclaimer":"passed"}
   policy check 0199c2d4-...  (npm run policy -- 0199c2d4-...)
```

Each policy check runs in the background. Resume one from its ID, from any process, and print what the judge cited:

```bash
npm run policy -- <policy check id>
```

## Verify

`reply-guard` judges each answer with `observe.verify` before the API replies. Its two assertions run in milliseconds and call no model:

- `no-refund-promise` fails any answer containing "guaranteed refund".
- `no-ai-disclaimer` fails any answer that says "as an AI".

An answer either requirement fails is never sent. The question above baits the agent into quoting "guaranteed refund", so the customer gets a hand-off to billing instead.

`policy-check` judges each answer with `observe.submit`, so the reply never waits for it. A reader agent opens `service/refund-policy.pdf` and lists its rules with their pages, and a judge decides whether the answer follows them, citing the page it relied on.

## Observe

Each request is a Wyrd Run. The question, the answer, both Verifiers' results, and the agent's trace are stored in Bifrost under one `run_id`, including answers that were blocked.

```bash
npm run query         # SQL: verdict counts, and each blocked answer with its trace
npm run investigate   # an agent answers questions about the evidence over Wyrd's MCP endpoint
```
