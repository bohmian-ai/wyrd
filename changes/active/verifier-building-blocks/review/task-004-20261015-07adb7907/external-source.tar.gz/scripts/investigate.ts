/**
 * Ask an agent about the evidence. An OpenAI Agents SDK agent connects to Wyrd
 * over MCP and answers by writing its own Bifrost SQL.
 *
 *   npm run investigate -- "Which answers did no-refund-promise block, and why?"
 */

import { Agent, MCPServerStreamableHttp, OpenAIResponsesModel, run } from "@openai/agents";
import { WyrdState } from "wyrd-ai";

import { gateway, wyrd as wyrdClient } from "../src/agent.ts";
import { BUNDLE_DIR, CONVERSATIONS, verifierNames } from "../src/wyrd.ts";

const question =
  process.argv[2] ??
  "Which support-agent answers failed verification? For each, give the question, which Verifier and " +
    "requirement failed it, and how long the model call took.";

const state = WyrdState.fromPath(BUNDLE_DIR);

const wyrd = new MCPServerStreamableHttp({
  url: `${wyrdClient.serverUrl}/mcp`,
  fetch: wyrdClient.httpAuth, // the gateway's client adds its Wyrd access token to every MCP request
  // Read-only tools only, so the investigator cannot change anything.
  toolFilter: { allowedToolNames: ["wyrd.guide", "bifrost.list_tables", "bifrost.describe_table", "bifrost.query"] },
});
await wyrd.connect();

const investigator = new Agent({
  name: "wyrd-investigator",
  instructions:
    "You investigate a support agent's verification evidence in Wyrd. Use bifrost.describe_table before " +
    "querying a table, and answer from bifrost.query results only. Cite run IDs.\n" +
    `Conversations: ${CONVERSATIONS}. Verdicts: vala.verification.results (verifier_card_uid is the ` +
    "Verifier, card_uid the judged Card). " +
    "Traces: vala.traces.spans (the 'support-agent' span is one answer). All three join on run_id.\n" +
    `Verifiers by UID: ${JSON.stringify(Object.fromEntries(verifierNames(state)))}.`,
  // OpenAI serves tool calls with reasoning only on its Responses API.
  model: new OpenAIResponsesModel(gateway, "openai/gpt-6-luna"),
  modelSettings: { reasoning: { effort: "medium" } },
  mcpServers: [wyrd],
});

const result = await run(investigator, question, { maxTurns: 12 });
console.log(result.finalOutput);
await wyrd.close();
