/**
 * Resume a background policy check from its execution ID alone, wait for its
 * result, and print each requirement with the policy pages it cites.
 *
 *   npm run policy -- <policy_check from npm run ask>
 */

import { verify } from "wyrd-ai";

const id = process.argv[2];
if (!id) throw new Error("usage: npm run policy -- <execution id>");

const result = await (await verify.Execution.connect(id)).wait({ timeoutMs: 120_000 });
console.log(`policy-check: ${result.outcome.verdict}`);
for (const requirement of result.outcome.requirements) {
  const pages = (requirement.citations ?? []).map(({ locator }) => JSON.stringify(locator)).join(", ");
  console.log(`  ${requirement.id}: ${requirement.outcome} (${requirement.reason}) ${pages}`);
}
