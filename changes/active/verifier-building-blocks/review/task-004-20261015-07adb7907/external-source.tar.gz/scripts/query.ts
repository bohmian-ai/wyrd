/**
 * Read the evidence back with SQL. Every row a Run produced shares its
 * `run_id`, so one join links a conversation to its trace and verdicts.
 */

import { Bifrost, WyrdState } from "wyrd-ai";
import { z } from "zod";

import { BUNDLE_DIR, CONVERSATIONS, cardUid, verifierNames } from "../src/wyrd.ts";

const state = WyrdState.fromPath(BUNDLE_DIR);
const verifiers = verifierNames(state);
const bifrost = await Bifrost.connect();

// 1. Verdicts per Verifier for this agent version. Integer aggregates are bigint.
const verdicts = await bifrost.sql(
  `SELECT verifier_card_uid, verdict, COUNT(*) AS n
     FROM vala.verification.results
    WHERE card_uid = $1
    GROUP BY verifier_card_uid, verdict`,
  [cardUid(state, "agent")],
  z.object({ verifier_card_uid: z.string(), verdict: z.string(), n: z.bigint() }),
);
for (const row of verdicts) console.log(`${verifiers.get(row.verifier_card_uid)}: ${row.verdict} x${row.n}`);

// 2. Every blocked answer, with how long the agent took to draft it.
const blocked = await bifrost.sql(
  `SELECT c.run_id, c.question, c.answer, s.duration_nano / 1000000 AS agent_ms
     FROM ${CONVERSATIONS} c
     JOIN vala.traces.spans s ON s.run_id = c.run_id AND s.name = 'support-agent'
    WHERE NOT c.delivered`,
  [],
  z.object({ run_id: z.string(), question: z.string(), answer: z.string(), agent_ms: z.bigint() }),
);
console.log("\nBlocked answers:");
console.table(blocked);

await bifrost.shutdown();
