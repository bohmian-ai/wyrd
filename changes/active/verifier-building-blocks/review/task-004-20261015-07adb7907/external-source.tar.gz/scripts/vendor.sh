#!/bin/sh
# Build wyrd-ai from a Wyrd checkout and pack it, with this host's native
# addon, into vendor/ as the tarballs package.json installs. No symlinks: the
# installed package is exactly what `npm publish` would ship.
#
#   npm run vendor -- ../wyrd && npm install
set -eu
wyrd=$(cd "${1:?usage: npm run vendor -- <path to a wyrd checkout>}" && pwd)
sdk="$wyrd/sdks/wyrd-sdk-ts"
(cd "$wyrd" && mise run ts:build)
addon=$(cd "$sdk/wyrd" && ls wyrd.*.node)
target=${addon#wyrd.}
target=${target%.node}
stage=$(mktemp -d)
trap 'rm -rf "$stage"' EXIT
cp "$sdk/wyrd-$target/package.json" "$sdk/wyrd/$addon" "$stage"
rm -rf vendor
mkdir vendor
npm pack --silent --pack-destination vendor "$sdk/wyrd" >/dev/null
npm pack --silent --pack-destination vendor "$stage" >/dev/null
mv vendor/wyrd-ai-0.1.0.tgz vendor/wyrd-ai.tgz
mv "vendor/wyrd-ai-$target-0.1.0.tgz" "vendor/wyrd-ai-$target.tgz"
