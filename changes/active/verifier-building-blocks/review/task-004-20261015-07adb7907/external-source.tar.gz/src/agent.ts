/**
 * The support agent: a plain OpenAI Agents SDK agent that calls models through
 * the Wyrd gateway. Its model and instructions come from the
 * `support-prompt` Card, not from code.
 */

import { Agent, OpenAIChatCompletionsModel, run, setTraceProcessors } from "@openai/agents";
import OpenAI from "openai";
import { WyrdAgentsTraceProcessor, WyrdClient, type Run, type WyrdState } from "wyrd-ai";

import { cardUid } from "./wyrd.ts";

// Send the Agents SDK's traces to Wyrd instead of OpenAI. Each agent, model
// call, and tool call becomes an OpenTelemetry span under the request's Run.
setTraceProcessors([new WyrdAgentsTraceProcessor()]);

// The gateway is OpenAI-compatible. `wyrd.httpAuth` replaces the placeholder
// key with a fresh Wyrd access token on every request, exchanged from WYRD_API_KEY.
export const wyrd = WyrdClient.connect();
export const gateway = new OpenAI({ baseURL: `${wyrd.serverUrl}/v1`, apiKey: "wyrd", fetch: wyrd.httpAuth });

/** Answer one question inside a Wyrd Run. */
export async function answer(state: WyrdState, wyrdRun: Run, question: string): Promise<string> {
  const { model, system } = state.prompt("prompt").spec;
  if (!system) throw new Error("support-prompt must declare its system instructions");

  // These headers tie the gateway's record of this call to the Run.
  const client = gateway.withOptions({
    defaultHeaders: { "wyrd-run-id": wyrdRun.runId, "wyrd-card-uid": cardUid(state, "agent") },
  });
  const agent = new Agent({
    name: "support-agent",
    instructions: system,
    model: new OpenAIChatCompletionsModel(client, `openai/${model}`),
  });
  const result = await run(agent, question);
  return result.finalOutput ?? "";
}
