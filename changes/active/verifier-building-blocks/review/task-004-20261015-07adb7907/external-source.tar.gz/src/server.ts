/**
 * The support API: `POST /ask {"question": "..."}`.
 *
 * Each request is one Wyrd Run: answer the question, gate the answer with
 * `reply-guard` now, submit it to `policy-check` in the background, record
 * the conversation, and reply. An answer the gate fails is never sent; the
 * customer gets a hand-off instead.
 */

import { createServer } from "node:http";
import { json } from "node:stream/consumers";

import { WyrdState, verify } from "wyrd-ai";

import { answer } from "./agent.ts";
import { BUNDLE_DIR, CONVERSATIONS, POLICY, outcomes } from "./wyrd.ts";

const HANDOFF = "I've passed your question to our billing team. They reply within one business day.";

// The registered Service, downloaded by `wyrd get`. Everything else reaches
// the server named by WYRD_SERVER_URL.
const state = WyrdState.fromPath(BUNDLE_DIR);
await state.startBifrost(); // writes records to Bifrost
await state.startTelemetry(); // exports spans to Wyrd

async function ask(question: string) {
  const wyrdRun = state.run("agent");
  // Spans started inside the scope carry the Run's ID.
  return wyrdRun.scope(async () => {
    const started = performance.now();
    const draft = await answer(state, wyrdRun, question);

    // The gate judges now; a failed verdict is a result, not an error.
    const guard = await wyrdRun.observe.verify("reply-guard", { answer: draft });
    const delivered = guard.outcome.verdict === "passed";
    // The policy check reads the PDF and calls a judge, so it runs in the
    // background; its execution ID resumes it from any process.
    const submitted = await wyrdRun.observe.submit("policy-check", {
      answer: draft,
      policy: verify.File.path(POLICY),
    });

    // Recorded even when blocked, so the failure stays auditable.
    await wyrdRun.observe.record(CONVERSATIONS, {
      conversation_id: wyrdRun.runId,
      question,
      answer: draft,
      delivered,
      latency_ms: Math.round(performance.now() - started),
    });

    return {
      run_id: wyrdRun.runId,
      answer: delivered ? draft : HANDOFF,
      delivered,
      checks: outcomes(guard),
      policy_check: submitted.kind === "queued" ? submitted.execution.id : undefined,
    };
  });
}

/** The reply body of `POST /ask`. */
export type AskReply = Awaited<ReturnType<typeof ask>>;

const server = createServer(async (request, response) => {
  const { question } = (await json(request)) as { question?: string };
  if (!question) {
    response.writeHead(400).end('send {"question": "..."}');
    return;
  }
  const reply = await ask(question);
  response.writeHead(200, { "content-type": "application/json" }).end(JSON.stringify(reply));
});

const port = Number(process.env.PORT ?? 3000);
server.listen(port, () => console.log(`support-api listening on http://127.0.0.1:${port}`));

// Flush every span and record before exiting.
process.once("SIGINT", async () => {
  server.close();
  await state.shutdown();
  process.exit(0);
});
