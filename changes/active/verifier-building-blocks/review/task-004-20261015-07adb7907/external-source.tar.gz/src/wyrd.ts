/** Names shared by the API and the scripts. */

import { resolve } from "node:path";

import type { VerificationResult, WyrdState } from "wyrd-ai";

/** Where `wyrd get` downloads the registered Service. */
export const BUNDLE_DIR = resolve(import.meta.dirname, "../.wyrd-bundle");

/** The refund policy every answer is checked against. */
export const POLICY = resolve(import.meta.dirname, "../service/refund-policy.pdf");

/** The Bifrost table the Service declares. */
export const CONVERSATIONS = "vala.datasets.conversations";

/** The registered UID of a Card in the bundle. Bifrost rows name Cards by UID. */
export const cardUid = (state: WyrdState, alias: string): string => state.cardRef(alias).uid!;

/** Each Verifier's name, keyed by its Card UID. */
export const verifierNames = (state: WyrdState): Map<string, string> =>
  new Map(
    state.aliases
      .filter((alias) => state.card(alias).kind === "Verifier")
      .map((alias) => [cardUid(state, alias), state.card(alias).metadata.name]),
  );

/** Each requirement's outcome in `result`, keyed by requirement ID. */
export const outcomes = (result: VerificationResult): Record<string, string> =>
  Object.fromEntries(result.outcome.requirements.map((requirement) => [requirement.id, requirement.outcome]));
