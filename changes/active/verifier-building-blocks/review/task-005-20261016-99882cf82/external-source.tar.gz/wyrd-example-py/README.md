# wyrd-example-py

A customer-support API whose answers Wyrd checks against a refund policy. It is a small FastAPI app with an [OpenAI Agents SDK](https://openai.github.io/openai-agents-python/) agent; Wyrd supplies the model gateway, the verification, and the evidence.

Every answer is checked by one Verifier, `policy-check`, which takes the answer and the policy PDF:

1. An agent reads the policy with `fs.read` and lists its refund rules, each with its page.
2. `no-refund-promise` fails any answer that contains "guaranteed refund".
3. `follows-policy` asks a second agent, which has no tools, whether the answer follows those rules. It cites the policy page it relied on.

## Layout

| Path | What it holds |
| --- | --- |
| `service/` | The Cards: the `support-desk` Service and its `tickets` table, the support agent and prompt, the `policy-check` Verifier, its two agents, and `refund-policy.pdf`. |
| `src/desk.py` | The agent, the Wyrd Run around each question, and the two ways to check an answer: `verify` now, or `submit` for later. |
| `src/app.py` | The HTTP API. |
| `scripts/` | `deploy` registers the Cards, `review` waits for a background check, and `evidence` reads one Run's records from Bifrost. |
| `test/` | The whole flow against a real Wyrd server and a scripted local model. |

## The API

| Request | Returns |
| --- | --- |
| `POST /ask {"question": ...}` | The answer and its verdict. The answer is checked before the reply goes out. |
| `POST /reviews {"question": ...}` | The answer and an `execution_id`. The check runs in the background. |
| `GET /reviews/{execution_id}` | The check's `status` and, once it is `completed`, its verdict and requirement breakdown. |

Each requirement in a breakdown has an `id`, an `outcome` (`passed`, `failed`, `inconclusive`, or `not_applicable`), a `reason`, and, for `follows-policy`, `citations` such as `{"slot": "policy", "locator": {"page": 1}}`.

## Quickstart

This runs the whole flow against a local Wyrd server with a scripted model, so you need no model API key. You need Python 3.11+, [uv](https://docs.astral.sh/uv/), and Docker.

1. Build the Wyrd Python SDK into `vendor/`. It is not on PyPI yet. From a Wyrd checkout, with its `mise` toolchain:

   ```bash
   cd sdks/wyrd-sdk-python
   uv sync --group dev
   mise exec -- uv run maturin build --release --features testing --out /path/to/wyrd-example-py/vendor
   ```

   `--features testing` adds `wyrd.testing.WyrdTestServer`, which the tests use. Then, in this repository:

   ```bash
   uv sync
   ```

2. Start PostgreSQL for the test server. It needs an administrator that can create databases, and two logins for the server to serve with:

   ```bash
   docker run -d --name wyrd-test-postgres -p 127.0.0.1:5439:5432 \
     -e POSTGRES_USER=wyrd_test_admin -e POSTGRES_PASSWORD=admin -e POSTGRES_DB=wyrd postgres:16
   until docker exec wyrd-test-postgres pg_isready -h 127.0.0.1 -q; do sleep 1; done
   docker exec wyrd-test-postgres psql -U wyrd_test_admin -d wyrd \
     -c "CREATE ROLE wyrd_platform LOGIN PASSWORD 'platform'" \
     -c "CREATE ROLE wyrd_tenant LOGIN PASSWORD 'tenant'"

   export WYRD_TEST_DATABASE_ADMIN_URL=postgres://wyrd_test_admin:admin@127.0.0.1:5439/wyrd
   export WYRD_DATABASE_URL=postgres://wyrd_tenant:tenant@127.0.0.1:5439/wyrd
   export WYRD_PLATFORM_DATABASE_URL=postgres://wyrd_platform:platform@127.0.0.1:5439/wyrd
   ```

3. Run the tests:

   ```bash
   uv run pytest
   ```

   Each test session starts a Wyrd server in its own fresh database, points its gateway at a local model in `test/conftest.py`, registers `service/`, and drives the API. The tests check that:

   - a normal answer passes both requirements, and `follows-policy` cites page 1 of the policy;
   - an answer that promises a guaranteed refund fails `no-refund-promise`;
   - a background review is read back by its execution ID alone, with the same breakdown;
   - one Run's ticket, request span, gateway call, and verdict join in one Bifrost query.

   Set `WYRD_LOG=info` to see the server's log.

## Run it with OpenAI

This needs a published Wyrd server release for `wyrd server install`, PostgreSQL, and an `OPENAI_API_KEY`. The SDK from the quickstart includes the `wyrd` CLI.

1. Start PostgreSQL and a local server, and leave it running:

   ```bash
   docker run -d --name wyrd-postgres -p 127.0.0.1:5432:5432 -e POSTGRES_PASSWORD=postgres postgres:16
   until docker exec wyrd-postgres pg_isready -h 127.0.0.1 -q; do sleep 1; done
   docker exec wyrd-postgres psql -U postgres -c "CREATE ROLE wyrd LOGIN PASSWORD 'wyrd'" -c "CREATE DATABASE wyrd OWNER wyrd"

   export WYRD_DATABASE_URL=postgresql://wyrd:wyrd@127.0.0.1:5432/wyrd
   uv run wyrd server install
   uv run wyrd server dev --tenant support
   ```

   `server dev` saves the server's URL and an admin key, so the commands below need no setup. Open a second terminal in this directory.

2. Store your OpenAI key with the server and add the `openai` deployment the agents use. The app never sees the key:

   ```bash
   uv run python -c 'import json, os; print(json.dumps({"name": "openai", "provider": "openai", "source": {"managed_secret": {"secret": os.environ["OPENAI_API_KEY"]}}}))' \
     | uv run wyrd gateway credential put --file -
   echo '{"name": "openai", "adapter": "openai", "auth": {"bearer": {"credential": "openai"}}}' \
     | uv run wyrd gateway deployment put --file -
   ```

3. Register the Cards and download them into `.wyrd-bundle`:

   ```bash
   uv run python -m scripts.deploy
   ```

4. Start the API:

   ```bash
   uv run uvicorn src.app:app --port 8000
   ```

5. In another terminal, ask a question. The reply carries the verdict:

   ```bash
   curl -s localhost:8000/ask -H 'content-type: application/json' \
     -d '{"question": "Can I get a refund for a pair of boots I bought 40 days ago?"}'
   ```

6. Queue a review instead, then read it back by its execution ID:

   ```bash
   curl -s localhost:8000/reviews -H 'content-type: application/json' \
     -d '{"question": "Where is order 7?"}'
   curl -s localhost:8000/reviews/<execution_id>
   uv run python -m scripts.review <execution_id>   # waits up to 120 seconds for the result
   ```

7. Read everything Wyrd recorded for a Run:

   ```bash
   uv run python -m scripts.evidence <run_id>
   ```

## How it uses Wyrd

- **Cards.** `scripts/deploy.py` registers `service/support-desk.yaml` and the Cards it references, then downloads them with `Cards.hydrate`. `Desk` loads that bundle with `WyrdState.from_path`, and takes its model and prompt from the `support-prompt` Card.
- **Gateway.** The agent's OpenAI client points at the Wyrd server and authenticates with `WyrdClient.http_auth`, which sends a fresh Wyrd access token on every request. The `wyrd-run-id` and `wyrd-card-uid` headers tie each model call to its Run.
- **Telemetry.** `WyrdState.start_telemetry` exports spans to Wyrd, and `WyrdAgentsTraceProcessor` turns the Agents SDK's traces into spans. Spans started inside `with run:` carry that Run.
- **Verification.** `run.observe.verify` checks an answer and returns the result. `run.observe.submit` queues the check and returns a `verify.Execution`. Any process can rebuild that handle with `verify.Execution.connect(execution_id)` and call `status()` or `wait(timeout)`.
- **Evidence.** `scripts/evidence.py` joins `vala.datasets.tickets`, `vala.traces.spans`, `vala.gateway.calls`, and `vala.verification.results` on `run_id` with `Bifrost.sql`.

## Checks

```bash
uv run ruff format --check . && uv run ruff check . && uv run ty check src scripts test
```
