"""Wait for a background review by its execution ID and print its breakdown.

uv run python -m scripts.review <execution_id>
"""

from __future__ import annotations

import sys

from wyrd import verify


def main(execution_id: str) -> None:
    result = verify.Execution.connect(execution_id).wait(120)
    print(f"{result.verdict}  (run {result.run_id})")
    for requirement in result.requirements:
        print(f"  {requirement['id']}: {requirement['outcome']}  {requirement['reason']}")
        for citation in requirement.get("citations", []):
            print(f"    cites {citation['slot']} {citation['locator']}")


if __name__ == "__main__":
    main(sys.argv[1])
