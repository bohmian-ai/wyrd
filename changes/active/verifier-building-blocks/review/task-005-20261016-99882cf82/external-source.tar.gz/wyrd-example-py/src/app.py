"""The support API.

- ``POST /ask`` answers a question and verifies the answer before replying.
- ``POST /reviews`` answers a question and queues the check in the background.
- ``GET /reviews/{execution_id}`` reads a queued check's status and, once it
  is done, its requirement breakdown.

Run it with ``uv run uvicorn src.app:app``.
"""

from __future__ import annotations

import asyncio
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from typing import Any

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from wyrd import WyrdError, verify

from src.desk import Desk


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None]:
    app.state.desk = Desk()
    yield
    # Flush buffered tickets and spans to Wyrd before exiting.
    app.state.desk.state.shutdown()


app = FastAPI(title="support-desk", lifespan=lifespan)


class Question(BaseModel):
    question: str


@app.exception_handler(WyrdError)
async def wyrd_error(request: Request, error: WyrdError) -> JSONResponse:
    """Reply with Wyrd's own status and stable error code."""
    return JSONResponse({"code": error.code, "message": str(error)}, status_code=error.status)


@app.post("/ask")
async def ask(body: Question, request: Request) -> dict[str, Any]:
    desk: Desk = request.app.state.desk
    run, answer = await desk.answer(body.question)
    # Verification blocks until the verdict is in, so it runs off the event loop.
    result = await asyncio.to_thread(desk.check, run, answer)
    return {
        "run_id": run.run_id,
        "answer": answer,
        "verdict": result.verdict,
        "requirements": result.requirements,
    }


@app.post("/reviews")
async def review(body: Question, request: Request) -> dict[str, Any]:
    desk: Desk = request.app.state.desk
    run, answer = await desk.answer(body.question)
    execution = await asyncio.to_thread(desk.submit, run, answer)
    return {"run_id": run.run_id, "answer": answer, "execution_id": execution.id}


@app.get("/reviews/{execution_id}")
def review_status(execution_id: str, request: Request) -> dict[str, Any]:
    # Any process can pick a check up from its execution ID alone.
    state = verify.Execution.connect(execution_id, request.app.state.desk.client).status()
    reply: dict[str, Any] = {"execution_id": execution_id, "status": state["status"]}
    if "result" in state:
        outcome = state["result"]["outcome"]
        reply |= {"verdict": outcome["verdict"], "requirements": outcome["requirements"]}
    if "error" in state:
        reply["error"] = state["error"]
    return reply
