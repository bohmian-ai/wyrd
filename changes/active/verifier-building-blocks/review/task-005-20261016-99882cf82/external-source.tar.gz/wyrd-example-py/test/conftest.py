"""A real Wyrd test server whose gateway reaches a scripted local model, so
the suite needs no model API key.

The local model answers like this:

- the policy reader first calls ``fs.read`` (``fs_read`` to the model) on the
  policy, then lists its rule;
- the policy judge passes, citing page 1 of the policy;
- the support agent promises a guaranteed refund when asked about refunds and
  otherwise says the order is on its way.
"""

from __future__ import annotations

import json
import threading
from collections.abc import Iterator
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import pytest
from fastapi.testclient import TestClient
from wyrd.gateway import Gateway
from wyrd.testing import WyrdTestServer, cli

from scripts.deploy import deploy
from src.app import app

READ_POLICY = {
    "role": "assistant",
    "content": None,
    "tool_calls": [
        {
            "id": "call-read-policy",
            "type": "function",
            "function": {"name": "fs_read", "arguments": '{"path": "/inputs/policy.pdf"}'},
        }
    ],
}
FINDINGS = json.dumps(
    {"findings": [{"rule": "Refunds of up to 100 dollars are approved within 30 days.", "page": 1}]}
)
VERDICT = json.dumps(
    {
        "outcome": "passed",
        "reason": "consistent with the policy",
        "citations": [{"slot": "policy", "locator": {"page": 1}}],
    }
)


def reply(body: dict) -> dict:
    """The local model's next message for one Chat Completions request."""
    text = json.dumps(body)
    if "list its refund rules" in text:
        read = any(message.get("role") == "tool" for message in body["messages"])
        return {"role": "assistant", "content": FINDINGS} if read else READ_POLICY
    if "Claim:" in text:
        return {"role": "assistant", "content": VERDICT}
    if "refund" in text:
        return {"role": "assistant", "content": "You have a guaranteed refund."}
    return {"role": "assistant", "content": "Your order is on its way."}


class LocalModel(BaseHTTPRequestHandler):
    def do_POST(self) -> None:
        body = json.loads(self.rfile.read(int(self.headers["content-length"])))
        completion = {
            "id": "chatcmpl-local",
            "object": "chat.completion",
            "created": 1,
            "model": body["model"],
            "choices": [{"index": 0, "finish_reason": "stop", "message": reply(body)}],
            "usage": {"prompt_tokens": 5, "completion_tokens": 3, "total_tokens": 8},
        }
        payload = json.dumps(completion).encode()
        self.send_response(200)
        self.send_header("content-type", "application/json")
        self.send_header("content-length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def log_message(self, format: str, *args: object) -> None:
        pass


@pytest.fixture(scope="session")
def server() -> Iterator[WyrdTestServer]:
    """The server, exporting ``WYRD_SERVER_URL`` and the tenant administrator's
    ``WYRD_API_KEY`` to the app, as ``wyrd server dev`` saves them."""
    model = ThreadingHTTPServer(("127.0.0.1", 0), LocalModel)
    threading.Thread(target=model.serve_forever, daemon=True).start()
    url = f"http://127.0.0.1:{model.server_address[1]}"
    try:
        with (
            WyrdTestServer(verification_runtime=True, provider_base_url=url) as server,
            pytest.MonkeyPatch.context() as env,
        ):
            env.setenv("WYRD_API_KEY", server.tenant_admin_key())
            yield server
    finally:
        model.shutdown()


@pytest.fixture(scope="session")
def api(server: WyrdTestServer) -> Iterator[TestClient]:
    """The deployed support API, with the ``openai`` deployment the quickstart creates."""
    cli.put_provider_credential(
        {
            "name": "openai",
            "provider": "openai",
            "source": {"managed_secret": {"secret": "sk-local"}},
        }
    )
    Gateway().put_deployment(
        {"name": "openai", "adapter": "openai", "auth": {"bearer": {"credential": "openai"}}}
    )
    deploy()
    with TestClient(app) as client:
        yield client
