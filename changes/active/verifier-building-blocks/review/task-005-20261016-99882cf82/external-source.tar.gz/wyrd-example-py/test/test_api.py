"""The support API end to end against a real Wyrd server."""

from __future__ import annotations

from fastapi.testclient import TestClient
from wyrd import verify
from wyrd.testing import WyrdTestServer

from scripts.evidence import evidence
from src.app import app

POLICY_PAGE_1 = [{"slot": "policy", "locator": {"page": 1}}]


def ask(api: TestClient, path: str, question: str) -> dict:
    response = api.post(path, json={"question": question})
    assert response.status_code == 200, response.text
    return response.json()


def outcomes(requirements: list[dict]) -> list[tuple[str, str]]:
    return [(each["id"], each["outcome"]) for each in requirements]


def test_ask_passes_an_answer_that_keeps_to_the_policy(api: TestClient) -> None:
    reply = ask(api, "/ask", "Where is order 7?")

    assert reply["answer"] == "Your order is on its way."
    assert reply["verdict"] == "passed"
    assert outcomes(reply["requirements"]) == [
        ("no-refund-promise", "passed"),
        ("follows-policy", "passed"),
    ]
    assert reply["requirements"][1]["citations"] == POLICY_PAGE_1


def test_ask_fails_a_refund_promise(api: TestClient) -> None:
    reply = ask(api, "/ask", "Can I get a refund for order 7?")

    assert reply["answer"] == "You have a guaranteed refund."
    assert reply["verdict"] == "failed"
    assert outcomes(reply["requirements"]) == [
        ("no-refund-promise", "failed"),
        ("follows-policy", "passed"),
    ]


def test_review_is_read_back_by_execution_id(api: TestClient) -> None:
    queued = ask(api, "/reviews", "Can I get a refund for order 8?")

    # Waiting needs nothing but the execution ID, as in another process.
    result = verify.Execution.connect(queued["execution_id"]).wait(120)
    assert result.run_id == queued["run_id"]

    status = api.get(f"/reviews/{queued['execution_id']}").json()
    assert status["status"] == "completed"
    assert status["verdict"] == "failed"
    assert outcomes(status["requirements"]) == [
        ("no-refund-promise", "failed"),
        ("follows-policy", "passed"),
    ]
    assert status["requirements"][1]["citations"] == POLICY_PAGE_1


def test_review_status_refuses_a_malformed_execution_id(api: TestClient) -> None:
    refused = api.get("/reviews/not-an-execution")

    assert refused.status_code == 400
    assert refused.json()["code"] == "WYRD_SPEC_400_VALIDATION"


def test_evidence_joins_one_runs_records(api: TestClient, server: WyrdTestServer) -> None:
    reply = ask(api, "/ask", "Where is order 9?")
    app.state.desk.state.flush()
    server.flush_bifrost()

    rows = evidence(reply["run_id"])

    assert rows, "the Run has joined evidence"
    assert {row["verdict"] for row in rows} == {"passed"}
    assert {row["answer"] for row in rows} == {"Your order is on its way."}
