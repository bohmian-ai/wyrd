# wyrd-example-rs

A customer-support API in Rust (axum) where Wyrd checks every answer against the refund policy. You can check an answer before replying, or send it for a background review and read the verdict later by its ID.

## What's in it

```text
service/   the Cards: the Service, its Agent and Prompt, the policy-check Verifier, and refund-policy.pdf
src/       the app: lib.rs has the routes, main.rs deploys and serves
scripts/   evidence.rs prints one Run's joined evidence from Bifrost
test/      an end-to-end test against a real Wyrd server and a local fake model
```

`service/policy-check.yaml` takes two inputs, `answer` (JSON) and `policy` (the PDF), and runs three checks:

- step `findings`: the `policy-reader` Agent opens the PDF with `fs.read` and lists the refund rules, each with its page number.
- requirement `no-refund-promise`: an assertion that fails if the answer contains "guaranteed refund".
- requirement `follows-policy`: the `policy-judge` Agent, which has no tools, compares the answer with the findings and cites the policy page it relied on.

Every answer comes from the `support-agent` Card through `Run::invoke`, so the model call goes through the Wyrd gateway inside a Wyrd Run. `start_telemetry` exports the request spans to Wyrd and stamps each one with its Run. The ticket row, the span, the gateway call, and the verdict all carry the same `run_id`.

## Quickstart

You need Rust (the pinned toolchain in `rust-toolchain.toml` installs itself through rustup), Docker, a Wyrd checkout next to this directory (see [Where the SDK comes from](#where-the-sdk-comes-from)), and the `wyrd` CLI (`pip install wyrd-ai` or `npm install -g wyrd-ai`).

1. Start PostgreSQL and a local Wyrd server:

   ```bash
   docker run -d --name wyrd-postgres -p 5432:5432 -e POSTGRES_PASSWORD=postgres postgres:16
   until docker exec wyrd-postgres pg_isready -q; do sleep 1; done
   docker exec wyrd-postgres psql -U postgres -c "CREATE ROLE wyrd LOGIN PASSWORD 'wyrd'" -c "CREATE DATABASE wyrd OWNER wyrd"
   export WYRD_DATABASE_URL=postgresql://wyrd:wyrd@127.0.0.1:5432/wyrd
   wyrd server dev --tenant support
   ```

   `server dev` saves the server URL and the admin key, so the app and the CLI pick them up without any more setup. Leave it running and open a new terminal.

2. Connect a model. The Agents call `gpt-4o` through a gateway deployment named `openai`. To use OpenAI, see [Live provider setup](#live-provider-setup).

3. Run the app:

   ```bash
   cargo run --bin support-desk
   ```

   On startup the app registers `service/`, downloads the Service into `.wyrd-bundle/`, and listens on `http://127.0.0.1:3000`. Set `ADDR` to listen somewhere else.

4. Ask a question and get the answer checked before you reply:

   ```bash
   curl -s localhost:3000/ask -H 'content-type: application/json' \
     -d '{"question": "Can I get a refund for order 7?"}'
   ```

   The response has `run_id`, `answer`, and `check`. `check.verdict` is `passed`, `failed`, or `inconclusive`, and `check.requirements` lists every requirement with its `outcome`, its `reason`, and, for `follows-policy`, its policy `citations`. If the answer promises a "guaranteed refund", `no-refund-promise` fails and so does the verdict.

5. Send an answer for background review, then read it back by ID:

   ```bash
   curl -s localhost:3000/review -H 'content-type: application/json' \
     -d '{"question": "Can I get a refund for order 7?"}'
   # {"run_id": "...", "answer": "...", "execution_id": "..."}

   curl -s localhost:3000/review/<execution_id>
   # {"status": "pending" | "running" | "completed" | ..., "check": null until completed}
   ```

   `/review` returns as soon as the review is queued. `/review/{id}` needs only the ID, so another process, or this app after a restart, can read the result.

6. See everything Wyrd kept for one Run:

   ```bash
   cargo run --bin evidence -- <run_id>
   ```

   It joins `vala.datasets.tickets`, `vala.traces.spans`, `vala.gateway.calls`, and `vala.verification.results` on `run_id` through Bifrost. Rows show up a few seconds after the request.

## The SDK calls

| What | Where | Call |
|---|---|---|
| Register and hydrate the Cards | `SupportDesk::deploy` | `Cards::register_from_path`, `Cards::hydrate`, `WyrdState::from_path_with` |
| Call the model in a Run | `SupportDesk::answer` | `state.run_for_card("agent")`, `run.invoke`, `run.scope` |
| Export spans | `main` | `wyrd_ai::otel::start_telemetry` |
| Check now | `ask` | `run.observe().verify("policy-check", inputs)` |
| Check in the background | `review` | `run.observe().submit(...)` gives `Submission::Queued(execution)` |
| Read a check by ID | `review_status` | `verify::Execution::connect_with(id, client).status()` |
| Query the evidence | `evidence` | `Bifrost::sql_as` |

To block until a background check finishes, use `Execution::connect(id).await?.wait(timeout)`, which polls with backoff and gives up after `timeout`.

## Live provider setup

This step is needed only for real model calls. The automated test uses a local fake model and needs no key.

```bash
export OPENAI_API_KEY=sk-...
python3 -c 'import json, os; print(json.dumps({"name": "openai", "provider": "openai", "source": {"managed_secret": {"secret": os.environ["OPENAI_API_KEY"]}}}))' \
  | wyrd gateway credential put --file -
wyrd gateway deployment put --file - <<<'{"name": "openai", "adapter": "openai", "auth": {"bearer": {"credential": "openai"}}}'
```

The gateway keeps the key. The app never sees it and sends no provider headers of its own.

## Test

`test/support_desk.rs` starts a real Wyrd server on a temporary Postgres database, points the `openai` deployment at a local OpenAI-compatible fake model ([wiremock](https://crates.io/crates/wiremock)), and calls the app over HTTP. It checks:

- an ordinary answer passes `/ask`;
- a refund promise fails `/ask`, with `no-refund-promise` failed and `follows-policy` passed and citing page 1 of the policy;
- a `/review` is read back from `/review/{id}` by its execution ID, with the same breakdown;
- that Run's ticket, span, gateway call, and verdict join through Bifrost.

The test needs Docker for Postgres, so it is `#[ignore]`d by default, the same way the Wyrd repository gates its server tests. Run it through the Wyrd checkout's Postgres wrapper:

```bash
../wyrd-verifier-building-blocks/scripts/postgres/with-test-postgres.sh -- cargo test -- --ignored
```

Plain `cargo test` builds everything and skips the server test.

## Where the SDK comes from

`Cargo.toml` depends on the Wyrd Rust SDK (`wyrd-ai`) and, for the test, the Wyrd test server (`wyrd-testing`) through `path` dependencies on a Wyrd checkout at `../wyrd-verifier-building-blocks`. Cargo builds a path dependency the same way it builds a published crate, so nothing is symlinked or vendored. To use a different checkout, change the two paths. To build from git instead:

```toml
wyrd-ai = { git = "https://github.com/bohmian-ai/wyrd", branch = "main", package = "wyrd-ai", features = ["otel"] }
wyrd-testing = { git = "https://github.com/bohmian-ai/wyrd", branch = "main", package = "wyrd-testing" }
```

Once `wyrd-ai` is published, use `wyrd-ai = { version = "0.1", features = ["otel"] }`.

The `[patch.crates-io]` block copies the Wyrd workspace's DataFusion and Arrow fork pins, because Cargo applies patches only from the top-level workspace. Keep it in sync with the Wyrd version you build against.
