//! Print one Run's joined evidence: its ticket, request span, gateway call,
//! and policy-check verdict, read through Bifrost.
//!
//!     cargo run --bin evidence -- <run_id>

use wyrd_ai::WyrdClient;
use wyrd_example_rs::evidence;

/// Print the evidence of the Run named on the command line.
///
/// # Errors
/// Returns a usage error without a Run ID, and the client or query error.
#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let run_id = std::env::args()
        .nth(1)
        .ok_or("usage: cargo run --bin evidence -- <run_id>")?;
    let rows = evidence(&WyrdClient::from_global()?, &run_id).await?;
    if rows.is_empty() {
        println!("no joined evidence for Run {run_id} yet; try again in a few seconds");
    }
    for row in rows {
        println!("{row:#?}");
    }
    Ok(())
}
