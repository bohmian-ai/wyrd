//! Deploy the support desk to the Wyrd server the ambient configuration names
//! (what `wyrd server dev` saved, or `WYRD_SERVER_URL` and `WYRD_API_KEY`) and
//! serve it on `127.0.0.1:3000`, or on `ADDR`.

use wyrd_ai::WyrdClient;
use wyrd_ai::otel::start_telemetry;
use wyrd_example_rs::SupportDesk;

/// Deploy, export every request span to Wyrd, serve until Ctrl-C, then flush
/// the spans and ticket rows still buffered.
///
/// # Errors
/// Returns the client configuration, deploy, telemetry, bind, or shutdown
/// error.
#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let client = WyrdClient::from_global()?;
    let desk = SupportDesk::deploy(&client, ".wyrd-bundle".as_ref()).await?;
    let state = desk.state().clone();
    let telemetry = start_telemetry(&state)?;
    let addr = std::env::var("ADDR").unwrap_or_else(|_| "127.0.0.1:3000".to_owned());
    let listener = tokio::net::TcpListener::bind(&addr).await?;
    println!("support desk listening on http://{addr}");
    axum::serve(listener, desk.router())
        .with_graceful_shutdown(async {
            let _ = tokio::signal::ctrl_c().await;
        })
        .await?;
    telemetry.shutdown()?;
    state.shutdown().await?;
    Ok(())
}
