//! The support desk against a real Wyrd server and a deterministic local
//! OpenAI-compatible model, so no model API key is needed.
//!
//! Needs Postgres; run it through the Wyrd checkout's Postgres wrapper:
//!
//!     ../wyrd-verifier-building-blocks/scripts/postgres/with-test-postgres.sh -- cargo test -- --ignored

use std::collections::BTreeSet;
use std::time::Duration;

use reqwest::Client;
use secrecy::{ExposeSecret, SecretString};
use serde_json::{Value, json};
use wiremock::matchers::{body_string_contains, method, path};
use wiremock::{Mock, MockServer, ResponseTemplate};
use wyrd_ai::config::ClientConfig;
use wyrd_ai::gateway::{
    AbsoluteUrl, DeploymentAccess, GatewayOperation, ProviderAdapter, ProviderAuth,
    ProviderDeployment, ProviderDeploymentName,
};
use wyrd_ai::otel::start_telemetry;
use wyrd_ai::transport::{GrpcConfig, HttpConfig};
use wyrd_ai::{Gateway, WyrdClient};
use wyrd_example_rs::{SupportDesk, evidence};
use wyrd_testing::server::WyrdTestServer;

/// Answer every Chat Completions request whose body contains `marker` with
/// `content`; the lowest `priority` wins when several markers match.
async fn answer(model: &MockServer, marker: &str, content: &str, priority: u8) {
    Mock::given(method("POST"))
        .and(path("/v1/chat/completions"))
        .and(body_string_contains(marker))
        .respond_with(ResponseTemplate::new(200).set_body_json(json!({
            "id": "chatcmpl-example",
            "object": "chat.completion",
            "created": 1,
            "model": "gpt-4o",
            "choices": [{
                "index": 0,
                "message": { "role": "assistant", "content": content },
                "finish_reason": "stop",
            }],
            "usage": { "prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2 },
        })))
        .with_priority(priority)
        .mount(model)
        .await;
}

/// The local model: the policy reader finds one rule on page 1, the judge
/// passes and cites it, and the support Agent promises a guaranteed refund
/// to every refund question.
async fn local_model() -> MockServer {
    let model = MockServer::start().await;
    answer(
        &model,
        "list its refund rules",
        r#"{"findings":[{"rule":"Refunds of up to 100 dollars are approved within 30 days.","page":1}]}"#,
        1,
    )
    .await;
    answer(
        &model,
        "Claim:",
        r#"{"outcome":"passed","reason":"consistent with the policy","citations":[{"slot":"policy","locator":{"page":1}}]}"#,
        1,
    )
    .await;
    answer(&model, "refund", "You have a guaranteed refund.", 2).await;
    answer(
        &model,
        "Answer the customer",
        "Your order is on its way.",
        3,
    )
    .await;
    model
}

/// POST `body` to `url` and return the JSON reply.
///
/// # Panics
/// Panics when the request fails or the app does not answer 200.
async fn post(http: &Client, url: &str, body: Value) -> Value {
    let reply = http
        .post(url)
        .json(&body)
        .send()
        .await
        .expect("app answers");
    assert_eq!(
        reply.status(),
        200,
        "{}",
        reply.text().await.unwrap_or_default()
    );
    reply.json().await.expect("JSON reply")
}

/// Each requirement's id and outcome in `check`.
fn outcomes(check: &Value) -> Vec<(String, String)> {
    check["requirements"]
        .as_array()
        .expect("requirements")
        .iter()
        .map(|r| {
            (
                r["id"].as_str().unwrap_or_default().to_owned(),
                r["outcome"].as_str().unwrap_or_default().to_owned(),
            )
        })
        .collect()
}

/// An ordinary answer passes now, a refund promise fails now with the
/// requirement breakdown and the judge's policy citation, a background review
/// is read back by its execution ID alone, and the failing Run's ticket,
/// span, gateway call, and verdict join through Bifrost.
///
/// # Panics
/// Panics when any step fails or a verdict, outcome, or joined value differs.
#[tokio::test(flavor = "multi_thread")]
#[ignore = "requires Postgres; see the module docs"]
async fn answers_are_verified_now_and_in_the_background() {
    let model = local_model().await;
    let server = WyrdTestServer::builder()
        .without_process_telemetry_for_test()
        .with_verification_runtime_for_test()
        .with_gateway_provider_root_for_test(model.uri().parse().expect("model URL"))
        .start_bound()
        .await
        .expect("Wyrd starts");
    // The tenant administrator key, as `wyrd server dev` saves it.
    let api_key = server.tenant_admin_key().await.expect("administrator key");
    let client = WyrdClient::with_config(ClientConfig {
        http: HttpConfig {
            base_url: server.base_url().expect("HTTP URL").to_owned(),
            ..HttpConfig::default()
        },
        grpc: GrpcConfig {
            endpoint: server.grpc_url().expect("gRPC URL"),
            ..GrpcConfig::default()
        },
        credential: Some(SecretString::from(api_key.expose_secret())),
        ..ClientConfig::default()
    })
    .expect("client builds");
    // The `openai` deployment the Agents name, served by the local model.
    Gateway::connect_with(&client)
        .await
        .expect("gateway connects")
        .put_deployment(&ProviderDeployment {
            name: ProviderDeploymentName::new("openai").expect("deployment name"),
            adapter: ProviderAdapter::OpenAiCompatible {
                base_url: AbsoluteUrl::new(format!("{}/v1", model.uri())).expect("model URL"),
            },
            auth: ProviderAuth::None,
            models: None,
            capabilities: Some(BTreeSet::from([GatewayOperation::ChatCompletions])),
            access: DeploymentAccess::Open,
        })
        .await
        .expect("deployment puts");

    let bundle = tempfile::tempdir().expect("bundle directory");
    let desk = SupportDesk::deploy(&client, &bundle.path().join("bundle"))
        .await
        .expect("the desk deploys");
    let state = desk.state().clone();
    let telemetry = start_telemetry(&state).expect("telemetry starts");
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0")
        .await
        .expect("binds");
    let app = format!("http://{}", listener.local_addr().expect("address"));
    tokio::spawn(async move { axum::serve(listener, desk.router()).await });
    let http = Client::new();

    let passed = post(
        &http,
        &format!("{app}/ask"),
        json!({ "question": "Where is order 1?" }),
    )
    .await;
    assert_eq!(passed["answer"], "Your order is on its way.");
    assert_eq!(passed["check"]["verdict"], "passed", "{passed}");

    let failed = post(
        &http,
        &format!("{app}/ask"),
        json!({ "question": "Can I get a refund for order 2?" }),
    )
    .await;
    assert_eq!(failed["check"]["verdict"], "failed", "{failed}");
    assert_eq!(
        outcomes(&failed["check"]),
        [
            ("no-refund-promise".to_owned(), "failed".to_owned()),
            ("follows-policy".to_owned(), "passed".to_owned()),
        ]
    );
    assert_eq!(
        failed["check"]["requirements"][1]["citations"],
        json!([{ "slot": "policy", "locator": { "page": 1 } }])
    );

    let queued = post(
        &http,
        &format!("{app}/review"),
        json!({ "question": "Can I get a refund for order 3?" }),
    )
    .await;
    let id = queued["execution_id"].as_str().expect("an execution ID");
    let deadline = tokio::time::Instant::now() + Duration::from_secs(60);
    let reviewed = loop {
        let status: Value = http
            .get(format!("{app}/review/{id}"))
            .send()
            .await
            .expect("app answers")
            .json()
            .await
            .expect("JSON reply");
        if status["status"] == "completed" && !status["check"].is_null() {
            break status;
        }
        assert!(
            tokio::time::Instant::now() < deadline,
            "no result in time: {status}"
        );
        tokio::time::sleep(Duration::from_millis(250)).await;
    };
    assert_eq!(reviewed["check"]["verdict"], "failed", "{reviewed}");
    assert_eq!(outcomes(&reviewed["check"]), outcomes(&failed["check"]));

    state.flush().await.expect("tickets flush");
    telemetry.shutdown().expect("spans export");
    server.flush_bifrost().await.expect("rows publish");
    let run_id = failed["run_id"].as_str().expect("a Run ID");
    let rows = evidence(&client, run_id).await.expect("evidence reads");
    assert!(!rows.is_empty(), "Run {run_id} has joined evidence");
    for row in &rows {
        assert_eq!(row.ticket_id, run_id);
        assert_eq!(row.span, "support-desk.ask");
        assert_eq!(row.verdict, "failed");
    }

    state.shutdown().await.expect("the desk shuts down");
    server.shutdown().await.expect("Wyrd shuts down");
}
