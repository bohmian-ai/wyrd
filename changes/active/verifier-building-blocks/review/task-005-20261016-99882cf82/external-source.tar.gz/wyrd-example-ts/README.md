# wyrd-example-ts

A small customer-support API verified by Wyrd. Every answer is checked against
the store's refund policy PDF by one Verifier, `policy-check`:

- `findings`: an Agent (`policy-reader`) reads the PDF with `fs.read` and lists its refund rules with their pages;
- `no-refund-promise`: an assertion fails any answer containing "guaranteed refund";
- `follows-policy`: a tool-less Agent (`policy-judge`) judges the answer against those findings and cites the policy page.

The app is plain Node `http` plus the OpenAI Agents SDK. Model calls go through
the Wyrd gateway, authenticated by the SDK (`fetch: wyrd.httpAuth`), so the app
never holds a provider key.

| Path | What it is |
|---|---|
| `service/` | The Cards: the `support-api` Service, its agent and prompt, `policy-check` with its two Agents, and `refund-policy.pdf`. |
| `src/agent.ts` | The support agent, with model and instructions read from the `support-prompt` Card. |
| `src/server.ts` | The API: `POST /ask`, `POST /review`, `GET /review/<execution_id>`. |
| `scripts/` | `deploy`, `ask`, `evidence`, and the `vendor`/`test` helpers. |
| `test/` | The whole app against a real Wyrd server with a deterministic local model. |

## Install

You need Node.js 24+, Docker, and a Wyrd checkout with its toolchain (`mise install`) to build the SDK from.

```bash
npm run vendor -- ../wyrd   # builds wyrd-ai and packs it, with this host's native addon, into vendor/
npm install
```

`vendor/` holds the same tarballs `npm publish` would ship, so this is a normal
package install, not a link into the checkout. Rerun both after pulling Wyrd.
npm warns that the other platforms' addon tarballs are missing; that is expected.

## Test (no model key needed)

```bash
npm test
```

The test starts a throwaway PostgreSQL container and an in-process Wyrd server
from the SDK's test harness, with a local OpenAI-compatible model that answers
deterministically. It checks an immediate pass, an immediate fail with its
requirement breakdown and policy citations, a background review read back by
execution ID, and one Run's evidence joined through Bifrost.

## Quickstart against a live provider

### 1. Start a Wyrd server

```bash
docker run -d --name wyrd-postgres -p 5432:5432 -e POSTGRES_PASSWORD=postgres postgres:16
until docker exec wyrd-postgres pg_isready -q; do sleep 1; done
docker exec wyrd-postgres psql -U postgres -c "CREATE ROLE wyrd LOGIN PASSWORD 'wyrd'" -c "CREATE DATABASE wyrd OWNER wyrd"
export WYRD_DATABASE_URL=postgresql://wyrd:wyrd@127.0.0.1:5432/wyrd

npx wyrd server install
npx wyrd server dev --tenant acme
```

Leave it running and open a new terminal here. `server dev` saved the server
URL and admin key, so the `npx wyrd` and `npm run deploy` commands below need no setup.

### 2. Connect OpenAI

Store your key in the gateway and add the `openai` deployment the Cards route through:

```bash
node -e 'console.log(JSON.stringify({name: "openai", provider: "openai", source: {managed_secret: {secret: process.env.OPENAI_API_KEY}}}))' \
  | npx wyrd gateway credential put --file -
npx wyrd gateway deployment put --file - <<<'{"name": "openai", "adapter": "openai", "auth": {"bearer": {"credential": "openai"}}}'
```

### 3. Deploy the Service and issue its key

```bash
npm run deploy
npx wyrd auth issue-key --kind Service --space default --name support-api --version 1.0.0
```

`deploy` registers everything in `service/`, which creates the
`vala.datasets.conversations` table, hydrates the Service into `.wyrd-bundle/`,
and turns on gateway call metadata capture. The key prints once; copy it.

### 4. Run it

```bash
export WYRD_API_KEY=<key from step 3>
npm start
```

In another terminal, with the same `WYRD_API_KEY`:

```bash
npm run ask
```

`ask` sends two questions to `POST /ask`, which answers and runs `policy-check`
with `verify` before replying. A refund question baits the agent into a
promise; the check fails and the customer gets a hand-off instead. It then
sends one question to `POST /review`, which replies at once with an execution
ID while `submit` queues the check on the server. `GET /review/<id>` reads its
status and, once completed, the requirement breakdown. `ask` itself waits for
the result with `verify.Execution.connect(id)` and `wait`: any process holding
the ID can.

### 5. Read the evidence

```bash
npm run evidence -- <run_id>
```

Each question is one Wyrd Run. The recorded conversation, the agent's span,
its gateway call, and the `policy-check` verdict all carry the Run's ID, so one
Bifrost query joins them.
