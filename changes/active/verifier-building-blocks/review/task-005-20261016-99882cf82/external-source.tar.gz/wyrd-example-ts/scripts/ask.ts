/**
 * Use the running API (`npm start`): two immediate checks, then one
 * background review read back by its execution ID.
 *
 *   npm run ask
 */

import { verify } from "wyrd-ai";

const API = process.env.API_URL ?? "http://127.0.0.1:3000";

async function call(path: string, question?: string) {
  const init = question === undefined ? {} : { method: "POST", body: JSON.stringify({ question }) };
  return (await (await fetch(`${API}${path}`, init)).json()) as Record<string, unknown>;
}

// 1. Immediate checks: the API verifies each answer before replying.
for (const question of ["Where is my order?", "Can I get a refund for my tent?"]) {
  const reply = await call("/ask", question);
  console.log(`Q: ${question}\nA: ${reply.answer}\n   ${reply.verdict}: ${JSON.stringify(reply.requirements)}\n`);
}

// 2. Background review: the answer goes out now, and the check runs on the server.
const queued = await call("/review", "Can I get a refund for order 7?");
console.log(`review queued: run ${queued.run_id}, execution ${queued.execution_id}`);
console.log("status now:", (await call(`/review/${queued.execution_id}`)).status);

// Any process holding the execution ID can wait for the result.
const execution = await verify.Execution.connect(String(queued.execution_id));
const result = await execution.wait({ timeoutMs: 120_000 });
console.log(`waited: ${result.outcome.verdict}`);

const done = await call(`/review/${queued.execution_id}`);
console.log(`status: ${done.status}, verdict: ${done.verdict}`);
for (const requirement of done.requirements as { id: string; outcome: string; reason: string }[]) {
  console.log(`  ${requirement.id}: ${requirement.outcome} (${requirement.reason})`);
}
console.log(`\nnpm run evidence -- ${queued.run_id}`);
