#!/bin/sh
# Run `npm test`: the tests start an in-process Wyrd server (the SDK's test
# harness) on a throwaway PostgreSQL container. Needs Docker; no model key.
set -eu
name=wyrd-example-ts-test-$$
docker run -d --rm --name "$name" -p 127.0.0.1::5432 --tmpfs /var/lib/postgresql/data \
  -e POSTGRES_USER=admin -e POSTGRES_PASSWORD=admin -e POSTGRES_DB=wyrd postgres:16 >/dev/null
trap 'docker rm -f "$name" >/dev/null' EXIT
until docker exec "$name" pg_isready -q -h 127.0.0.1 -U admin -d wyrd; do sleep 1; done
# The harness creates one database per server, owned by the platform login
# and served by the tenant login, as a two-login Wyrd deployment is.
docker exec "$name" psql -q -U admin -d wyrd \
  -c "CREATE ROLE wyrd_platform LOGIN PASSWORD 'platform'" -c "CREATE ROLE wyrd_tenant LOGIN PASSWORD 'tenant'"
address=$(docker port "$name" 5432/tcp | head -n 1)
export WYRD_TEST_DATABASE_ADMIN_URL="postgres://admin:admin@$address/wyrd"
export WYRD_PLATFORM_DATABASE_URL="postgres://wyrd_platform:platform@$address/wyrd"
export WYRD_DATABASE_URL="postgres://wyrd_tenant:tenant@$address/wyrd"
export WYRD_LOG="${WYRD_LOG:-warn}"
node --test "$@" test/*.test.ts
