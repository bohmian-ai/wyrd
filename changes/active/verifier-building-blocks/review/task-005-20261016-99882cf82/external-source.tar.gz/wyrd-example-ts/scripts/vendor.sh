#!/bin/sh
# Build wyrd-ai and its test harness from a Wyrd checkout and pack them, with
# this host's native addons, into vendor/ as the tarballs package.json
# installs. No symlinks: the installed package is exactly what `npm publish`
# would ship.
#
#   npm run vendor -- ../wyrd && npm install
set -eu
wyrd=$(cd "${1:?usage: npm run vendor -- <path to a wyrd checkout>}" && pwd)
sdk="$wyrd/sdks/wyrd-sdk-ts"
(cd "$wyrd" && mise run ts:build && mise run ts:build:testing)
addon=$(cd "$sdk/wyrd" && ls wyrd.*.node)
target=${addon#wyrd.}
target=${target%.node}
stage=$(mktemp -d)
trap 'rm -rf "$stage"' EXIT
mkdir "$stage/addon" "$stage/testing"
cp "$sdk/wyrd-$target/package.json" "$sdk/wyrd/$addon" "$stage/addon"
# The harness is a private workspace package; drop its workspace-only
# dependency on wyrd-ai, which the example installs itself.
cp "$sdk"/testing/index.* "$sdk"/testing/native.* "$sdk"/testing/*.node "$stage/testing"
cp "$sdk/testing/package.json" "$stage/testing/package.json"
node -e 'const fs = require("fs"), f = process.argv[1], p = JSON.parse(fs.readFileSync(f)); delete p.dependencies; delete p.private; fs.writeFileSync(f, JSON.stringify(p, null, 2))' "$stage/testing/package.json"
rm -rf vendor
mkdir vendor
npm pack --silent --pack-destination vendor "$sdk/wyrd" >/dev/null
npm pack --silent --pack-destination vendor "$stage/addon" >/dev/null
npm pack --silent --pack-destination vendor "$stage/testing" >/dev/null
mv vendor/wyrd-ai-0.1.0.tgz vendor/wyrd-ai.tgz
mv "vendor/wyrd-ai-$target-0.1.0.tgz" "vendor/wyrd-ai-$target.tgz"
mv vendor/wyrd-testing-0.1.0.tgz vendor/wyrd-testing.tgz
# Each build packs different bytes under the same version: drop the old
# tarballs' lockfile digests so `npm install` takes the new ones.
node -e 'const fs = require("fs"), lock = JSON.parse(fs.readFileSync("package-lock.json"));
for (const entry of Object.values(lock.packages)) if (entry.resolved?.startsWith("file:vendor/")) delete entry.integrity;
fs.writeFileSync("package-lock.json", JSON.stringify(lock, null, 2) + "\n")'
rm -rf node_modules/wyrd-ai node_modules/wyrd-ai-* node_modules/@wyrd
