/**
 * The support API, on Node's `http`:
 *
 *   POST /ask {"question": "..."}     answer and verify now; reply with the verdict
 *   POST /review {"question": "..."}  answer now, verify in the background; reply with the execution ID
 *   GET /review/<execution_id>        the review's status and, once done, its breakdown
 *
 * Every question is one Wyrd Run: the agent's spans, its gateway call, the
 * recorded conversation, and the `policy-check` result all carry its run ID.
 */

import { createServer } from "node:http";
import type { AddressInfo } from "node:net";
import { json } from "node:stream/consumers";

import type OpenAI from "openai";
import { type Run, type VerificationResult, verify, WyrdClient, WyrdError, WyrdState } from "wyrd-ai";

import { answer, gateway } from "./agent.ts";
import { BUNDLE_DIR, CONVERSATIONS, POLICY } from "./wyrd.ts";

/** What a customer gets instead of an answer that failed the policy check. */
export const HANDOFF = "I've passed your question to our billing team. They reply within one business day.";

/** What the API needs: the hydrated Service, the client it runs as, and the gateway. */
export interface Support {
  readonly state: WyrdState;
  readonly client: WyrdClient;
  readonly gateway: OpenAI;
}

/** The `policy-check` inputs: the answer, and the refund policy PDF it must keep to. */
function policyCheck(answer: string) {
  return { answer, policy: verify.File.path(POLICY) };
}

/** The verdict and each requirement's outcome, reason, and policy citations. */
export function breakdown(result: VerificationResult) {
  const requirements = result.outcome.requirements.map(({ id, outcome, reason, citations }) => ({
    id,
    outcome,
    reason,
    citations,
  }));
  return { verdict: result.outcome.verdict, requirements };
}

/** Answer `question` in a new Run, record the conversation, then `check` the answer within the Run. */
function answerInRun<T>(support: Support, question: string, check: (wyrdRun: Run, text: string) => Promise<T>) {
  const wyrdRun = support.state.run("agent");
  // Spans started inside the scope carry the Run's ID.
  return wyrdRun.scope(async () => {
    const text = await answer(support.gateway, support.state, wyrdRun, question);
    await wyrdRun.observe.record(CONVERSATIONS, { question, answer: text });
    return check(wyrdRun, text);
  });
}

/** Answer and verify now. An answer that fails the policy check is never sent. */
export function ask(support: Support, question: string) {
  return answerInRun(support, question, async (wyrdRun, text) => {
    const result = await wyrdRun.observe.verify("policy-check", policyCheck(text));
    const passed = result.outcome.verdict === "passed";
    return { run_id: wyrdRun.runId, answer: passed ? text : HANDOFF, ...breakdown(result) };
  });
}

/** Answer now and queue the policy check; the reply carries the execution ID to read it back by. */
export function review(support: Support, question: string) {
  return answerInRun(support, question, async (wyrdRun, text) => {
    const submitted = await wyrdRun.observe.submit("policy-check", policyCheck(text));
    if (submitted.kind !== "queued") throw new Error("policy-check judges Run evidence, so submit queues it");
    return { run_id: wyrdRun.runId, answer: text, execution_id: submitted.execution.id };
  });
}

/** Read a review by its execution ID alone, so any process holding the ID can serve it. */
export async function reviewStatus(support: Support, executionId: string) {
  const execution = await verify.Execution.connect(executionId, { client: support.client });
  const { status, error, result } = await execution.status();
  return { execution_id: executionId, status, error, ...(result ? breakdown(result) : {}) };
}

/** The HTTP server over {@link ask}, {@link review}, and {@link reviewStatus}. */
export function supportApi(support: Support) {
  return createServer(async (request, response) => {
    const reply = (status: number, body: unknown) =>
      response.writeHead(status, { "content-type": "application/json" }).end(JSON.stringify(body));
    const [, route, id] = (request.url ?? "").split("/");
    try {
      if (request.method === "GET" && route === "review" && id) {
        return reply(200, await reviewStatus(support, id));
      }
      if (request.method !== "POST" || (route !== "ask" && route !== "review") || id) {
        return reply(404, { error: "not found" });
      }
      const { question } = ((await json(request).catch(() => ({}))) ?? {}) as { question?: unknown };
      if (typeof question !== "string" || question === "") {
        return reply(400, { error: 'send {"question": "..."}' });
      }
      return route === "ask" ? reply(200, await ask(support, question)) : reply(202, await review(support, question));
    } catch (error) {
      if (error instanceof WyrdError) return reply(error.status, { code: error.code, detail: error.detail });
      console.error(error);
      return reply(500, { error: "internal error" });
    }
  });
}

if (import.meta.main) {
  // WYRD_SERVER_URL and WYRD_API_KEY say which server to use and who the app is.
  const client = WyrdClient.connect();
  // The registered Service, hydrated by `npm run deploy`.
  const state = WyrdState.fromPath(BUNDLE_DIR, { client });
  await state.startBifrost(); // writes conversations to Bifrost
  await state.startTelemetry(); // exports spans to Wyrd
  const server = supportApi({ state, client, gateway: gateway(client) });
  server.listen(Number(process.env.PORT ?? 3000), "127.0.0.1", () => {
    const { port } = server.address() as AddressInfo;
    console.log(`support-api listening on http://127.0.0.1:${port}`);
  });

  // Flush every span and row before exiting.
  for (const signal of ["SIGINT", "SIGTERM"]) {
    process.on(signal, async () => {
      server.close();
      await state.shutdown();
      process.exit(0);
    });
  }
}
