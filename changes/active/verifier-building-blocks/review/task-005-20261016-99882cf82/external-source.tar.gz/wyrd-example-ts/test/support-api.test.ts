/**
 * The whole app against a real Wyrd server: the SDK's in-process test server,
 * with a deterministic local model standing in for OpenAI, so no API key is
 * needed. The API runs as its own process with the Service's key, as it does
 * in the quickstart.
 */

import assert from "node:assert/strict";
import { type ChildProcess, spawn } from "node:child_process";
import { once } from "node:events";
import { mkdtempSync } from "node:fs";
import { createServer } from "node:http";
import type { AddressInfo } from "node:net";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { after, before, test } from "node:test";

import { cli, type NativeWyrdTestServer, startTestServer } from "@wyrd/testing";
import { Gateway, verify, WyrdClient } from "wyrd-ai";

import { deploy } from "../scripts/deploy.ts";
import { evidence } from "../scripts/evidence.ts";
import { HANDOFF } from "../src/server.ts";

/** The local model's reply, chosen by the first marker the request contains. */
const REPLIES = [
  // policy-reader: the refund rules, with the page each is on.
  ["list its refund rules", '{"findings":[{"rule":"Refunds of up to 100 dollars are approved within 30 days.","page":1}]}'],
  // policy-judge, for an answer that promises a refund.
  ["guaranteed refund", '{"outcome":"failed","reason":"the policy promises no refund","citations":[{"slot":"policy","locator":{"page":1}}]}'],
  // policy-judge, for any other answer.
  ["Claim:", '{"outcome":"passed","reason":"consistent with the policy","citations":[{"slot":"policy","locator":{"page":1}}]}'],
  // support-agent: a refund question baits it into a promise.
  ["get a refund", "You have a guaranteed refund."],
  ["", "Your order ships within two business days."],
] as const;

/** A local OpenAI-compatible Chat Completions endpoint answering by {@link REPLIES}. */
const model = createServer(async (request, response) => {
  let body = "";
  for await (const chunk of request) body += chunk;
  const content = REPLIES.find(([marker]) => body.includes(marker))?.[1];
  const message = { role: "assistant", content };
  response.writeHead(200, { "content-type": "application/json" }).end(
    JSON.stringify({
      id: "chatcmpl-local",
      object: "chat.completion",
      created: 1,
      model: "gpt-4o",
      choices: [{ index: 0, message, finish_reason: "stop", logprobs: null }],
      usage: { prompt_tokens: 1, completion_tokens: 1, total_tokens: 2 },
    }),
  );
});

let server: NativeWyrdTestServer;
let admin: WyrdClient;
let api: ChildProcess;
let url: string;

before(async () => {
  model.listen(0, "127.0.0.1");
  await once(model, "listening");
  server = startTestServer({
    providerBaseUrl: `http://127.0.0.1:${(model.address() as AddressInfo).port}`,
    verificationRuntime: true,
  });
  admin = WyrdClient.connect({ serverUrl: server.baseUrl, credential: server.tenantAdminKey(), grpcUrl: server.grpcUrl });

  // What the README's gateway setup does with a real OpenAI key.
  await cli.putProviderCredential(
    { name: "openai", provider: "openai", source: { managed_secret: { secret: "sk-local" } } },
    { client: admin },
  );
  await (await Gateway.connect({ client: admin })).putDeployment({
    name: "openai",
    adapter: "openai",
    auth: { bearer: { credential: "openai" } },
  });

  const scratch = mkdtempSync(join(tmpdir(), "wyrd-example-ts-"));
  const bundle = join(scratch, "bundle");
  await deploy(admin, bundle);
  const { key } = await cli.issueKey(
    { kind: "Service", space: "default", name: "support-api", version: "1.0.0" },
    { client: admin },
  );

  api = spawn(process.execPath, ["src/server.ts"], {
    env: {
      PATH: process.env.PATH,
      PORT: "0",
      BUNDLE_DIR: bundle,
      WYRD_CONFIG_HOME: scratch,
      WYRD_SERVER_URL: server.baseUrl,
      WYRD_GRPC_URL: server.grpcUrl,
      WYRD_API_KEY: key,
    },
    stdio: ["ignore", "pipe", "pipe"],
  });
  api.stderr!.on("data", (chunk) => process.stdout.write(`[api] ${chunk}`));
  const [line] = (await once(api.stdout!, "data")) as [Buffer];
  url = String(line).match(/http:\S+/)![0];
});

after(() => {
  api?.kill("SIGKILL");
  server?.shutdown();
  model.close();
});

async function call(path: string, question?: string) {
  const init = question === undefined ? {} : { method: "POST", body: JSON.stringify({ question }) };
  const response = await fetch(`${url}${path}`, init);
  return { status: response.status, body: (await response.json()) as Record<string, any> };
}

const POLICY_PAGE_1 = [{ slot: "policy", locator: { page: 1 } }];

let passedRun: string;

test("an answer within policy passes the immediate check", async () => {
  const { status, body } = await call("/ask", "Where is my order?");
  assert.equal(status, 200, JSON.stringify(body));
  assert.equal(body.answer, "Your order ships within two business days.");
  assert.equal(body.verdict, "passed");
  assert.deepEqual(
    body.requirements.map((r: any) => [r.id, r.outcome]),
    [["no-refund-promise", "passed"], ["follows-policy", "passed"]],
  );
  assert.deepEqual(body.requirements[1].citations, POLICY_PAGE_1);
  passedRun = body.run_id;
});

test("a refund promise fails the immediate check and is never sent", async () => {
  const { body } = await call("/ask", "Can I get a refund for my tent?");
  assert.equal(body.verdict, "failed");
  assert.equal(body.answer, HANDOFF);
  assert.deepEqual(
    body.requirements.map((r: any) => [r.id, r.outcome]),
    [["no-refund-promise", "failed"], ["follows-policy", "failed"]],
  );
  assert.deepEqual(body.requirements[1].citations, POLICY_PAGE_1);
});

test("a background review is read back by its execution ID", async () => {
  const queued = await call("/review", "Can I get a refund for order 7?");
  assert.equal(queued.status, 202);
  assert.equal(queued.body.answer, "You have a guaranteed refund.");
  const id = queued.body.execution_id;

  // This test process never submitted it: the ID alone is enough to wait.
  const result = await (await verify.Execution.connect(id, { client: admin })).wait({ timeoutMs: 120_000 });
  assert.equal(result.outcome.verdict, "failed");
  assert.equal(result.run_id, queued.body.run_id);

  const { body } = await call(`/review/${id}`);
  assert.equal(body.status, "completed");
  assert.equal(body.verdict, "failed");
  const [promise] = body.requirements;
  assert.equal(promise.id, "no-refund-promise");
  assert.equal(promise.outcome, "failed");
});

test("bad requests are refused", async () => {
  assert.equal((await call("/ask", "")).status, 400);
  assert.equal((await call("/review/not-an-execution-id")).status >= 400, true);
});

test("one Run's evidence joins through Bifrost", async () => {
  // Stopping the API flushes its spans and rows; the server then publishes them.
  api.kill("SIGINT");
  await once(api, "exit");
  server.flushBifrost();

  const rows = await evidence(passedRun, admin);
  assert.ok(rows.length > 0, "the Run has joined evidence");
  for (const row of rows) {
    assert.equal(row.run_id, passedRun);
    assert.equal(row.question, "Where is my order?");
    assert.equal(row.span, "invoke_agent support-agent");
    assert.equal(row.verdict, "passed");
  }
});
